
numGrid = 50;
inputEnv = unidrnd(2,1,numGrid)-1;

timeSteps = 510;
EnvMatrix = zeros(timeSteps,numGrid);
for i=1:timeSteps
	EnvMatrix(i,:)=inputEnv;
	inputEnv = UpdateEnvironment(inputEnv,numGrid,0.7,0.7,1);
end	

csvwrite("environment_0.7_0.7.csv", EnvMatrix);