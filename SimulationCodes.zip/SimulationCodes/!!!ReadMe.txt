READ ME
The file "RunSimulations-Example.m" inputs parameter values and calls one of the two main functions "simu_femChoiceEvolve_HardSoft.m" and "simu_femChoiceEvolve_SoftSoft". The former/latter simulates the scenario when females are under hard/soft selection, respectively. Note that males are always under soft selection.
The other "*.m" files are supporting functions called in the main functions. 
