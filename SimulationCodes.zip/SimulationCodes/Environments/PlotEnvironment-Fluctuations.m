
numGrid = 50;
inputEnv = unidrnd(2,1,numGrid)-1;

timeSteps = 12000;
EnvMatrix = zeros(timeSteps,numGrid);
for i=1:timeSteps
	EnvMatrix(i,:)=inputEnv;
	inputEnv = UpdateEnvironment(inputEnv,numGrid,0.999,0.999,1);
end	

csvwrite("environment_0.999_0.999.csv", EnvMatrix);