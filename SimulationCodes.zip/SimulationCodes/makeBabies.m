%%%%%%%%%%%%%%%%%%%%%  IMPORTANT!!! CHECK Genome Structure  %%%%%%%%%%%%%%%%%%%%%%

%phenotypeLocus = 1;
%sexualConflictLocus =2;
%dispMale = 3;
%dispFemale = 4;
%mateChoiceL1 = 5; %the "alpha" in the beta function, shape parameter
%mateChoiceL2 = 6; %the "beta" in the beta function, shape parameter
%sex = 7;
%habitat_natal = 8;
%habitat_breeding = 9;
%maleCondition_natal = 10;
%femaleCondition_natal =11;
%maleCondition_breeding = 12;
%femaleCondition_breeding =13;
%maleTotalCondition = 14;
%femaleTotalCondition = 15;
%femaleFecundity =16;


function [babyMatrix] = makeBabies(populationMatrix, MomIDs, DadIDs)
	popSize = length(MomIDs);
	babyMatrix = zeros(16,popSize);
	MomMatrix = populationMatrix(:,MomIDs);
	DadMatrix = populationMatrix(:,DadIDs);
	
	momAlleles = unidrnd(2,6,popSize)-1; % 5 is the number of evolving loci
	dadAlleles = 1 - momAlleles;
	
	babyMatrix(1:6,:) = MomMatrix(1:6,:) .* momAlleles + DadMatrix(1:6,:) .* dadAlleles;
	babyMatrix(7,:) = unidrnd(2,1,popSize)-1; %determine sex randomly
	babyMatrix(8,:) = MomMatrix(9,:); %offspring natal habitat is the mother's breeding habitat
end
