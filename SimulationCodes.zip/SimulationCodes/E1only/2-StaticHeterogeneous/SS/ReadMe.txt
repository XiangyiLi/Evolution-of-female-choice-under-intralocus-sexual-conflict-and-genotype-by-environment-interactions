We also did simulations for k2=0.1,0.2,...,0.9,1

Change the parameter value in file "RunSimulations-SS.m", change k2 to other values.