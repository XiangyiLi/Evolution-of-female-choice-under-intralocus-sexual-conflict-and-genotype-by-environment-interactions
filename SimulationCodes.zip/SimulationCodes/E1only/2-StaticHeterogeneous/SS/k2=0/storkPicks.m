function [parentMatrix] = storkPicks(popSize, femalesIdx, femalesFitness, malesIdx)
	parentPairs = [];
	for i=1:length(femalesIdx)
		numBabies = poissrnd(femalesFitness(i));
		if numBabies > 0
			newParentPairs = [femalesIdx(i); malesIdx(i)] .* ones(1,numBabies);
			parentPairs = [parentPairs, newParentPairs];
		end
	end
	if size(parentPairs)(2) < popSize
		parentMatrix = parentPairs;
	else
		storkPickedPairs = randperm(size(parentPairs)(2),popSize);
		parentMatrix = parentPairs(:,storkPickedPairs);
	end
end


