function [SAtraitDistr, alphaDistr, betaDistr, SummaryData] = simu_femChoiceEvolve_SS_AO(InputPopSize, NumHabitats, pSpatial, pTemporal, k, k1, k2, maxNumGenerations, InitDispProbMale, InitDispProbFemale, DeathLambda, delta, delta_femChoice, DispersalMode, DisperseCoevolveMode, NumRepeats)
	
	%pkg load statistics
	%%%%%%%% Individuals %%%%%%%%%
	phenotypeLocus = 1;
	sexualConflictLocus =2;
	dispMale = 3;
	dispFemale = 4;
	mateChoiceL1 = 5; %the "alpha" in the beta function, shape parameter
	mateChoiceL2 = 6; %the "beta" in the beta function, shape parameter
	sex = 7;
	habitat_natal = 8;
	habitat_breeding = 9;
	maleCondition_natal = 10;
	femaleCondition_natal =11;
	maleCondition_breeding = 12;
	femaleCondition_breeding =13;
	maleTotalCondition = 14;
	femaleTotalCondition = 15;
	femaleFecundity =16;
	
	totalNumLoci = femaleFecundity;
	
	%%%%%% Habitat initialisation %%%%%%%%%%%%%
	%randomStete=csvread("randStateFile.csv");
	%rand("state",randomStete);
	%inputE1 = unidrnd(2,1,NumHabitats)-1; 
	%E1 = UpdateEnvironment(inputE1,NumHabitats,pSpatial,pTemporal,500); %sexually concordant
	E1 = min(1,max(0,normrnd(0.5,0.2,1,NumHabitats)));
	
	%%%%%%%%%%% Initialise Population %%%%%%%%%%%%%
	pop = zeros(totalNumLoci, InputPopSize);
	% phenotype ranges from 0 to 1 for both the sexually concordant and antagonistic loci
	pop(phenotypeLocus:sexualConflictLocus,:) = rand(2,InputPopSize);
	% dispersal probability of males and females evolve independently
	pop(dispMale,:) = InitDispProbMale;
	pop(dispFemale,:) = InitDispProbFemale; 
	pop(mateChoiceL1:mateChoiceL2,:) = 1; % initially females prefer males equally
	
	
	% Sex: 0 -> female; 1 -> male; 1:1 sex ratio
	pop(sex,:)=unidrnd(2,1,InputPopSize)-1; 
	% individuals are randomly distributed on the habitats, initially.
	pop(habitat_natal,:) = unidrnd(NumHabitats, 1, InputPopSize);
	
	%%%%%%%%%%%% Output data %%%%%%%%%%%%
	SummaryData=[];
	
	t=0;
	
	while t < maxNumGenerations 
		t = t+1
		%%%%%%%% individual condition on the natal habitat %%%%%%%%%
		%%%%%%%% sexually concordant trait %%%%%%%%%
		for i=1:NumHabitats
			idx_males = find(and(pop(habitat_natal,:)==i, pop(sex,:)==1));
			Cond_c = FitnessOrder1(pop(phenotypeLocus,idx_males),E1(i),k); % effect of concordant trait on condition
			Cond_a = pop(sexualConflictLocus, idx_males); % male condition is proportional to the trait value.
			pop(maleCondition_natal, idx_males) = k2 * Cond_c + (1-k2) * Cond_a;
			
			idx_females = find(and(pop(habitat_natal,:)==i, pop(sex,:)==0));
			Cond_c = FitnessOrder1(pop(phenotypeLocus,idx_females),E1(i),k); % effect of concordant trait on condition
			Cond_a = 1 - pop(sexualConflictLocus, idx_females); % female condition is proportional to one minus the sexually antagonistic trait value.
			pop(femaleCondition_natal, idx_females) = k2 * Cond_c + (1-k2) * Cond_a;
		end
		
		%%%%%%%% dispersal happens, distance follows a geometric distribution %%%%%%
		idx_females=find(pop(sex,:)==0);
		idx_males = find(pop(sex,:)==1);
		switch DispersalMode
		case 1 % GeometricDispersal Kernel
			pop(habitat_breeding,idx_females)= GeometricDisperse(NumHabitats, pop(habitat_natal,idx_females), pop(dispFemale,idx_females), DeathLambda);
			pop(habitat_breeding,idx_males)= GeometricDisperse(NumHabitats, pop(habitat_natal,idx_males), pop(dispMale,idx_males), DeathLambda);
		case 2 % Uniform dispersal kernel
			pop(habitat_breeding,idx_females)= UniformDisperse(NumHabitats, pop(habitat_natal,idx_females), pop(dispFemale,idx_females), DeathLambda);
			pop(habitat_breeding,idx_males)= UniformDisperse(NumHabitats, pop(habitat_natal,idx_males), pop(dispMale,idx_males), DeathLambda);
		end
		
		%%%%%%%% individual condition on the breeding habitat, and total Condition %%%%%%%%%
		for i=1:NumHabitats
			idx_males = find(and(pop(habitat_breeding,:)==i, pop(sex,:)==1));
			Cond_c = FitnessOrder1(pop(phenotypeLocus,idx_males),E1(i),k);
			Cond_a = pop(sexualConflictLocus, idx_males); % male condition is proportional to the trait value.
			pop(maleCondition_breeding,idx_males) = k2 * Cond_c + (1-k2) * Cond_a;
			
			idx_females = find(and(pop(habitat_breeding,:)==i, pop(sex,:)==0));
			Cond_c = FitnessOrder1(pop(phenotypeLocus,idx_females),E1(i),k);
			Cond_a = 1 - pop(sexualConflictLocus, idx_females); % female condition is proportional to one minus the value of the sexually antagonistic trait.
			pop(femaleCondition_breeding, idx_females) = k2 * Cond_c + (1-k2) * Cond_a;
		end
		
		idx_males = find(and(pop(habitat_breeding,:) != 0, pop(sex,:) == 1));
		pop(maleTotalCondition, idx_males)= k1 * pop(maleCondition_natal, idx_males) + (1 - k1) * pop(maleCondition_breeding, idx_males);
		
		idx_females = find(and(pop(habitat_breeding,:) != 0, pop(sex,:) == 0));
		pop(femaleTotalCondition, idx_females)= k1 * pop(femaleCondition_natal, idx_females) + (1 - k1) * pop(femaleCondition_breeding, idx_females);
		
		
		%%%%%%%%% population census %%%%%%%%%%%%
		
		%mean dispersal probability of males and females
		meanMaleDisp = mean(pop(dispMale, idx_males));
		meanFemaleDisp = mean(pop(dispFemale, idx_females));
		
		%mean condition of males and females
		meanMaleCondition = mean(pop(maleTotalCondition, idx_males));
		meanFemaleConditon = mean(pop(femaleTotalCondition, idx_females));
		
		%mean alpha and beta of female choice curve
		meanAlpha = mean(pop(mateChoiceL1,idx_females));
		meanBeta = mean(pop(mateChoiceL2,idx_females));
		
		%mean SA traits of males and females
		meanSAtrait = mean(pop(sexualConflictLocus,:));
	
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%%%%%  mating %%%%%%%%%
		%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		% effective habitats: on which at least one male and one female, so breeding is possible
		effectiveHabs = EffectiveHabitats(NumHabitats, pop(habitat_breeding,:), pop(sex,:));
		NumEffectiveHabs = length(effectiveHabs);
		if NumEffectiveHabs < 1
			break;
		end
		
		NumOffspringPerPatch = InputPopSize/NumEffectiveHabs;
		
		%%%%%%%%%%%%%%% Polygyny %%%%%%%%%%%%
		MatrixMatches = [];
		%row 1 -> indices of females
		%row 2 -> fecundity of females
		%row 3 -> indices of males
		
		%%%%%%%%%% polygyny %%%%%%%
		% one female mate only with one male, but one male can mate with many females
		for i = effectiveHabs
			FemaleIDs = find(and(pop(habitat_breeding,:)==i, pop(sex,:)==0));
			maleIDs = find(and(pop(habitat_breeding,:)==i, pop(sex,:)==1));
			%Choose a male with condition X, X is a randomly chosen number according to each female's preferences
			MyChosenMaleCond = betarnd(pop(mateChoiceL1,FemaleIDs),pop(mateChoiceL2,FemaleIDs));
			maleCondList = pop(maleTotalCondition, maleIDs);
			%Find the ID of the males that has the closest condition matching each female's choice.
			[sortedList,ID_originals]=sort(maleCondList);
			edges = [-Inf, mean([sortedList(2:end); sortedList(1:end-1)]), +Inf];
			[~, IDinSorted] = histc(MyChosenMaleCond, edges);
			ChosenMaleIDs = maleIDs(ID_originals(IDinSorted));
			
			pop(femaleFecundity, FemaleIDs) = round(NumOffspringPerPatch / sum(pop(femaleTotalCondition, FemaleIDs)) * pop(femaleTotalCondition, FemaleIDs));
			
			newMatches = [FemaleIDs;pop(femaleFecundity,FemaleIDs);ChosenMaleIDs];
			MatrixMatches=[MatrixMatches, newMatches];
		end
			
		ParentMatrix = storkPicks(InputPopSize, MatrixMatches(1,:), MatrixMatches(2,:), MatrixMatches(3,:));		
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%%%%%  Making babies %%%%%%%%%
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		popSize = size(ParentMatrix)(2);
		
		babyMatrix = makeBabies(pop, ParentMatrix(1,:), ParentMatrix(2,:));
		
		%%%%%%%%%%offspring mutation
		% phenotype locus 
		mutations = normrnd(0,delta,2,popSize);
		babyMatrix(phenotypeLocus:sexualConflictLocus,:) = babyMatrix(phenotypeLocus:sexualConflictLocus,:) + mutations;
		babyMatrix(sexualConflictLocus,:) = min(1,max(0,babyMatrix(sexualConflictLocus,:)));
		% dispersal locus
		if DisperseCoevolveMode == 1
			mutations = normrnd(0,delta,2,popSize);
			babyMatrix(dispMale:dispFemale,:) = babyMatrix(dispMale:dispFemale,:) + mutations;
			babyMatrix(dispMale:dispFemale,:) = min(1,max(0,babyMatrix(dispMale:dispFemale,:))); %dispersal probability is bounded between 0 and 1
		end
		% female choice mutate
		mutations = normrnd(0,delta_femChoice,2,popSize);
		babyMatrix(mateChoiceL1:mateChoiceL2,:) = babyMatrix(mateChoiceL1:mateChoiceL2,:) + mutations;
		

	    %%%%%%%%% updating population %%%%%%%%%%
		pop = babyMatrix;
		
		%%%% Record population snapshot
		SummaryData =[SummaryData,[meanMaleDisp; meanFemaleDisp; meanMaleCondition; meanFemaleConditon; meanAlpha; meanBeta; meanSAtrait]];
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% updating environment %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%E1=UpdateEnvironment(E1,NumHabitats,pSpatial,pTemporal,1);
		
	end
	%SA trait distribution in the end
	edges = 0:0.05:1;
	SAtraitDistr=histc(pop(sexualConflictLocus,:),edges);
	%alpha value distribution in the end
	edges = 0:0.05:2;
	alphaDistr=histc(pop(mateChoiceL1,:),edges);
	%beta value distribution in the end
	betaDistr=histc(pop(mateChoiceL2,:),edges);
		
end
	
	