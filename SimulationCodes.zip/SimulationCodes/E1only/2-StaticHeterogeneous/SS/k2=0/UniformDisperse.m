function [HabitatsAfterDispersal]=UniformDisperse(numHabitats, CurrentHabitats, ProbOffspringDispersal,deathLambda)
	
popSize=length(CurrentHabitats);
HabitatsAfterDispersal=zeros(1,popSize);

for i=1:popSize
	currentHabitat=CurrentHabitats(i);
	willmove=rand<ProbOffspringDispersal(i);
	if willmove
		
		if rand<deathLambda
			continue;
		end
		
		currentHabitat=unidrnd(numHabitats);
		while currentHabitat == CurrentHabitats(i)
			currentHabitat=unidrnd(numHabitats);
		end

	end
	HabitatsAfterDispersal(i)=currentHabitat;
end

end


%%%%%%%%%%%%%%% Test the Function %%%%%%%%%%%%%
%numHabitats = 10;
%CurrentHabitats = 1*ones(1,50);
%ProbOffspringDispersal = 0.5*ones(1,50);
%newHabitats = PoissonDisperse(numHabitats, CurrentHabitats, ProbOffspringDispersal)