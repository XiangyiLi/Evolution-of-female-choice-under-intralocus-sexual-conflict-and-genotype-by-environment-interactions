%Variable and Parameter list:
%[SAtraitDisp, SummaryData] = simu_femChoiceEvolve(InputPopSize, NumHabitats, pSpatial, pTemporal, k, k1, k2, maxNumGenerations, InitDispProbMale, InitDispProbFemale, DeathLambda, delta, delta_femChoice, lambdaZero, DispersalMode, DisperseCoevolveMode, NumRepeats)

NumRepeats=30;
maxNumGenerations = 10000;

InitDispProbMale = 0.15;
InitDispProbFemale = 0.15;

InputPopSize = 5000;
NumHabitats = 50;
pSpatial = 0.5;
pTemporal = 0.5;
k=10;
k1=0.5; % the relative weight of natal habitat in determining condition
k2=0; % the relative weight of sexually concordant trait

DeathLambda = 0.1;
delta = 0.01;
delta_femChoice = 0.001;
lambdaZero = 5;

DispersalMode = 1; % 1->Geometric kernel; 2->Uniform kernel

DisperseCoevolveMode = 1; % 0-> disperesal probability is fixed; 1 -> sex specific dispersal probability coevolves 


for i=16:NumRepeats
	i
	x=[InputPopSize, NumHabitats, pSpatial, pTemporal, k, k1, k2, maxNumGenerations, InitDispProbMale, InitDispProbFemale, DeathLambda, delta, delta_femChoice, lambdaZero, DispersalMode, DisperseCoevolveMode];
	x=mat2cell(x,1,ones(1,length(x)));
	x{length(x)+1}=i;
	[SAtraitDistr,alphaDistr, betaDistr, SummaryData] = simu_femChoiceEvolve_AO(x{:});
	csvwrite([strcat("Result-Stats-k1", num2str(k1), "-k2-", num2str(k2), "-DispEvolve-", num2str(DispersalMode), "-Rep-", num2str(i), ".csv")], SummaryData);
	csvwrite([strcat("Result-SATraitDistribution-k1", num2str(k1), "-k2-", num2str(k2), "-DispEvolve-", num2str(DispersalMode), "-Rep-", num2str(i), ".csv")], SAtraitDistr);
	csvwrite([strcat("Result-alphaDistribution-k1", num2str(k1), "-k2-", num2str(k2), "-DispEvolve-", num2str(DispersalMode), "-Rep-", num2str(i), ".csv")], alphaDistr);
	csvwrite([strcat("Result-betaDistribution-k1", num2str(k1), "-k2-", num2str(k2), "-DispEvolve-", num2str(DispersalMode), "-Rep-", num2str(i), ".csv")], betaDistr);
end
