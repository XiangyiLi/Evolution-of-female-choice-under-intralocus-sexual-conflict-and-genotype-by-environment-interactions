We also did simulations for other fixed dispersal probabilities: 0.05,0.15,...0.65.

Change the parameter value in file "RunSimulations-SS.m", change "InitDispProbMale" and "InitDispProbFemale" to other values